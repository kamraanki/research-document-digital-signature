"use strict"
var express = require("express");
var router = express.Router();
var path = require("path");
var multer = require("multer");
var fs = require("fs");
var md5 = require("md5");
var {v4: uuidv4} = require("uuid");
var config = require("../config/config.json");
var Web3 = require("web3");
var web3 = new Web3(new Web3.providers.HttpProvider(config.infuraRopstenURL));

var crypto = require('crypto');
/* GET home page. */
router.get("/", function(req, res, next) {
    res.render("index.html");
});

/* Upload research document. */
router.post("/uploadResearchDocument", function(req, res, next) {
	// Upload document with the help of multer.
    upload(req, res, function(err) {
        if (err) {
            res.send({
                "error": "Internal server error."
            });
        } else {
        	// Calculate checksum for the file
            let fileBuffer = fs.readFileSync(req.file.path);
            let hashSum = crypto.createHash('md5');
            hashSum.update(fileBuffer);
            let hex = hashSum.digest('hex');
            // Check whether checksum matched with the checksum generated and signed at front end
            if (req.body.checksum === web3.utils.sha3(hex)) {
                res.send({
                    "success": true,
                    "documentId": req.file.filename.replace(".pdf", "")
                });
            } else {
                res.send({
                    "error": "File checksum and signed checksum does not match"
                });
            }
        }
    })
});

/* Download research document. */
router.post("/downloadResearchDocument", async function(req, res, next) {
    let documentId = req.body.documentId;
    if (documentId === undefined || documentId.trim().length === 0) {
        res.status(400);
        res.send({
            "error": "Please provide a valid document id."
        });
        return;
    }
    let dsvContract = new web3.eth.Contract(config.abi, config.contractAddress);
    // Get checksum for the given document id from chain
    let onChainHashedChecksum = await dsvContract.methods.getDocumentChecksum(documentId).call();
    if (onChainHashedChecksum === "0x0000000000000000000000000000000000000000000000000000000000000000") {
    	// Invalid document id
        res.status(404);
        res.send({
            "error": "Invalid document id. No such document found on chain."
        });
        return;
    }
    try {
    	// Calculate the checksum of local file
        let filePath = __dirname + "/../uploads/" + documentId + ".pdf";
        let fileBuffer = fs.readFileSync(filePath);
        let hashSum = crypto.createHash("md5");
        hashSum.update(fileBuffer);
        let hex = hashSum.digest("hex");
        let offChainHashedChecksum = web3.utils.sha3(hex);
        // Match the local file checksum with on chain checksum
        if (offChainHashedChecksum === onChainHashedChecksum) {
            // File hash verified with the on chain hash
            let fileName = path.basename(filePath);
            res.download(filePath, fileName);
            return;
        } else {
            res.status(409);
            res.send({
                "error": "File hash did not match with the on chain hash. File might be tempered."
            });
            return;
        }
    } catch (err) {
        res.status(500);
        res.send({
            "error": "Internal server error."
        });
        return;
    }
});

var storage = multer.diskStorage({
    destination: function(req, file, cb) {
        // Uploads is the Upload_folder_name
        cb(null, "uploads");
    },
    filename: function(req, file, cb) {
        cb(null, uuidv4() + ".pdf");
    }
});

// Define the maximum size for uploading
const maxSize = 1 * 1000 * 1000;
// Upload file with the help of multer
var upload = multer({
    storage: storage,
    limits: {
        fileSize: maxSize
    },
    fileFilter: function(req, file, cb) {

        // Set the filetypes, it is optional
        var filetypes = /pdf/;
        var mimetype = filetypes.test(file.mimetype);

        var extname = filetypes.test(path.extname(
            file.originalname).toLowerCase());

        if (mimetype && extname) {
            return cb(null, true);
        }

        cb("Error: File upload only supports the " +
            "following filetypes - " + filetypes);
    }

}).single("researchDocument");

module.exports = router;