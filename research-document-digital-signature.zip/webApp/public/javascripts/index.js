// Event listener for file selection and md5 hash calculation
document.getElementById('researchDocument').addEventListener('change', function() {
    var blobSlice = File.prototype.slice || File.prototype.mozSlice || File.prototype.webkitSlice,
        file = this.files[0],
        chunkSize = 2097152, // Read in chunks of 2MB
        chunks = Math.ceil(file.size / chunkSize),
        currentChunk = 0,
        spark = new SparkMD5.ArrayBuffer(),
        fileReader = new FileReader();

    fileReader.onload = function(e) {
        console.log('read chunk nr', currentChunk + 1, 'of', chunks);
        spark.append(e.target.result); // Append array buffer
        currentChunk++;

        if (currentChunk < chunks) {
            loadNext();
        } else {
            let md5Hash = spark.end();
            document.getElementById("researchDocumentChecksum").innerHTML = "MD5 Hash: " + md5Hash;
            document.getElementById("checksum").value = md5Hash;
            document.getElementById("hashedChecksum").value = "";
            document.getElementById("signature").value = "";
            document.getElementById("r").value = "";
            document.getElementById("s").value = "";
            document.getElementById("v").value = "";
        }
    };

    fileReader.onerror = function() {
        alert('oops, something went wrong.');
    };

    function loadNext() {
        var start = currentChunk * chunkSize,
            end = ((start + chunkSize) >= file.size) ? file.size : start + chunkSize;

        fileReader.readAsArrayBuffer(blobSlice.call(file, start, end));
    }

    loadNext();
});

//Event listener to sign message using meta mask
document.getElementById("signMessage").addEventListener("click", async function(event) {
    event.preventDefault();
    if (!window.ethereum) return alert("Please Install Metamask");
    let checksum = document.getElementById("checksum").value;
    if (checksum.trim().length === 0) return alert("Please select a valid file.");
    // connect and get metamask account
    const accounts = await ethereum.request({
        method: "eth_requestAccounts"
    });

    // message to sign
    const message = checksum;
    // hash message
    const hashedMessage = Web3.utils.sha3(message);
    // sign hashed message
    const signature = await ethereum.request({
        method: "personal_sign",
        params: [hashedMessage, accounts[0]],
    });

    // split signature
    const r = signature.slice(0, 66);
    const s = "0x" + signature.slice(66, 130);
    const v = parseInt(signature.slice(130, 132), 16);
    document.getElementById("hashedChecksum").value = hashedMessage;
    document.getElementById("signature").value = signature;
    document.getElementById("r").value = r;
    document.getElementById("s").value = s;
    document.getElementById("v").value = v;
});

document.getElementById("submitForm").addEventListener("click", async function(event) {
    event.preventDefault();
    let hashedChecksum = document.getElementById("hashedChecksum").value;
    let signature = document.getElementById("signature").value;
    let r = document.getElementById("r").value;
    let s = document.getElementById("s").value;
    let v = document.getElementById("v").value;
    if (hashedChecksum.trim().length === 0 || signature.trim().length === 0 || r.trim().length === 0 || s.trim().length === 0 || v.trim().length === 0) {
        alert("Please sign the checksum first !!");
        return false;
    }

    let formData = new FormData();
    formData.append("researchDocument", document.getElementById("researchDocument").files[0]);
    formData.append("checksum", hashedChecksum);
    $.ajax({
        url: '/uploadResearchDocument',
        type: 'POST',
        data: formData,
        success: async function(data) {
            if (data.error) {
                alert(data.error);
            } else if (data.success) {
                // Create, sign and broadcast the transaction
                let abi = [{
                    "inputs": [{
                        "internalType": "string",
                        "name": "",
                        "type": "string"
                    }],
                    "name": "documents",
                    "outputs": [{
                        "internalType": "bytes32",
                        "name": "",
                        "type": "bytes32"
                    }],
                    "stateMutability": "view",
                    "type": "function"
                }, {
                    "inputs": [{
                        "internalType": "string",
                        "name": "documentId",
                        "type": "string"
                    }],
                    "name": "getDocumentChecksum",
                    "outputs": [{
                        "internalType": "bytes32",
                        "name": "",
                        "type": "bytes32"
                    }],
                    "stateMutability": "view",
                    "type": "function"
                }, {
                    "inputs": [{
                        "internalType": "string",
                        "name": "documentId",
                        "type": "string"
                    }, {
                        "internalType": "bytes32",
                        "name": "_hashedMessage",
                        "type": "bytes32"
                    }, {
                        "internalType": "uint8",
                        "name": "_v",
                        "type": "uint8"
                    }, {
                        "internalType": "bytes32",
                        "name": "_r",
                        "type": "bytes32"
                    }, {
                        "internalType": "bytes32",
                        "name": "_s",
                        "type": "bytes32"
                    }],
                    "name": "registerDocumentChecksum",
                    "outputs": [],
                    "stateMutability": "nonpayable",
                    "type": "function"
                }];
                let contractAddres = "0xb7cd0dBFb31C664EFd78aDf2Ac8b01D649905026";
                let web3 = new Web3();
                let myContract = new web3.eth.Contract(abi, contractAddres);

                const transactionParameters = {
                    nonce: '0x00', // ignored by MetaMask
                    to: '0xb7cd0dBFb31C664EFd78aDf2Ac8b01D649905026', // Required except during contract publications.
                    from: ethereum.selectedAddress, // must match user's active address.
                    value: '0x00', // Only required to send ether to the recipient from the initiating external account.
                    data: myContract.methods.registerDocumentChecksum(data.documentId, hashedChecksum, v, r, s).encodeABI() // Used to prevent transaction reuse across blockchains. Auto-filled by MetaMask.
                };

                // txHash is a hex string
                // As with any RPC call, it may throw an error
                const txHash = await ethereum.request({
                    method: 'eth_sendTransaction',
                    params: [transactionParameters],
                });
                alert(data.documentId + " document successfully uploaded and transaction broadcasted.");

            }
        },
        cache: false,
        contentType: false,
        processData: false
    });
});

document.getElementById("downloadDoc").addEventListener("click", async function(event) {
    event.preventDefault();
    let documentId = document.getElementById("documentId").value;
    if(documentId.trim().length === 0) {
    	alert("Please provide a valid document id.");
    	return false;
    }
    let jsonData = {
        "documentId": documentId
    };
    $.ajax({
        url: '/downloadResearchDocument',
        type: 'POST',
        data: JSON.stringify(jsonData),
        xhrFields: function() {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 2) {
                    if (xhr.status == 200) {
                        xhr.responseType = "blob";
                    } else {
                        xhr.responseType = "text";
                    }
                }
            };
            return xhr;
        },
        success: function(response, status, xhr) {
            var filename = "";
            var disposition = xhr.getResponseHeader('Content-Disposition');
            if (disposition && disposition.indexOf('attachment') !== -1) {
                var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                var matches = filenameRegex.exec(disposition);
                if (matches != null && matches[1]) filename = matches[1].replace(/['"]/g, '');
            }

            var type = xhr.getResponseHeader('Content-Type');
            var blob = new Blob([response], {
                type: type
            });

            if (typeof window.navigator.msSaveBlob !== 'undefined') {
                window.navigator.msSaveBlob(blob, filename);
            } else {
                var URL = window.URL || window.webkitURL;
                var downloadUrl = URL.createObjectURL(blob);

                if (filename) {
                    var a = document.createElement("a");
                    if (typeof a.download === 'undefined') {
                        window.location = downloadUrl;
                    } else {
                        a.href = downloadUrl;
                        a.download = filename;
                        document.body.appendChild(a);
                        a.click();
                    }
                } else {
                    window.location = downloadUrl;
                }

                setTimeout(function() {
                    URL.revokeObjectURL(downloadUrl);
                }, 100); // cleanup
            }
        },
        error: function(xhr, textStatus, errorThrown) {
            console.log(xhr);
            alert(xhr.responseJSON.error);
        },
        cache: false,
        processData: false,
        contentType: "application/json; charset=utf-8"
    });
});